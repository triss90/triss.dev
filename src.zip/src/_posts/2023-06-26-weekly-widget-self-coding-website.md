---
layout: post
title: Weekly Widget - Self-coding Website
slug: weekly-widget-self-coding-website
date: 2023-06-26
draft: false
description: Weekly widget
category: web development
tags:
  - weekly widget
  - css
  - html
---

# Self-coding Website

<p class='timestamp'><time datetime='%%date%%'>%%date%%</time></p>
<hr>

The widget of the day is a self-coding website. While its practical applications may be limited, it could potentially be used as a tool for displaying examples:

<p class="codepen" data-height="794.81640625" data-default-tab="result" data-slug-hash="QBaEbq" data-user="triss90" style="height: 794.81640625px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/triss90/pen/QBaEbq">
  Self-coding Website</a> by Tristan  White (<a href="https://codepen.io/triss90">@triss90</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>
