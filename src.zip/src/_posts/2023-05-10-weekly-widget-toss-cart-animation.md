---
layout: post
title: Weekly Widget - "Toss" Add to Cart Animation
slug: weekly-widget-toss-cart-animation
date: 2023-05-10
draft: false
description: Weekly widget
category: web development
tags:
  - weekly widget
  - css
  - html
  - javascript
---

# "Toss" Add to Cart Animation

<p class='timestamp'><time datetime='10-05-2023'>10-05-2023</time></p>
<hr>

This week's widget is a fancy add to cart animation, made with CSS and a bit of JS to make it interactable, enjoy:

<p class="codepen" data-height="800" data-default-tab="result" data-slug-hash="vYEPxLY" data-user="triss90" style="height: 700px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/triss90/pen/vYEPxLY">
  "Toss" Add to Cart Animation</a> by Tristan  White (<a href="https://codepen.io/triss90">@triss90</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>
