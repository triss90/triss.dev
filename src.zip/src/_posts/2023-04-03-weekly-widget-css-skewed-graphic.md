---
layout: post
title: Weekly Widget - CSS Skewed Graphic
slug: weekly-widget-css-skewed-graphic
date: 2023-04-03
draft: false
description: Weekly widget
category: web development
tags:
  - weekly widget
  - css
  - html
---

# Weekly Widget - CSS Skewed Graphic

<p class='timestamp'><time datetime='03-04-2023'>03-04-2023</time></p>
<hr>

This week's widget is a simple skewed graphic, made with pure CSS, enjoy:

<p class="codepen" data-height="807.54296875" data-default-tab="result" data-slug-hash="PoYyNrO" data-user="triss90" style="height: 700px; box-sizing: border-box; display: flex; align-items: center; justify-content: center; border: 2px solid; margin: 1em 0; padding: 1em;">
  <span>See the Pen <a href="https://codepen.io/triss90/pen/PoYyNrO">
  CSS graphic</a> by Tristan  White (<a href="https://codepen.io/triss90">@triss90</a>)
  on <a href="https://codepen.io">CodePen</a>.</span>
</p>
<script async src="https://cpwebassets.codepen.io/assets/embed/ei.js"></script>
